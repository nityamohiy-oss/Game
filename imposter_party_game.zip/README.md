# Imposter Party — online multiplayer game

A browser-based private-room party game for **4–9 players**. Players create a room, share its five-character code, receive secret words privately, submit clues, vote, and reveal the imposters.

## Run locally

1. Install Node.js 18 or newer: https://nodejs.org/
2. Extract this folder.
3. Open a terminal in this folder and run:

   ```bash
   npm install
   npm start
   ```

4. Open http://localhost:3000

For friends on the same Wi-Fi, share your computer's local network IP and port 3000 (allow Node through your firewall if prompted).

## Put it online for friends in different locations

Deploy this folder to a Node.js hosting service that supports long-lived WebSocket connections (for example, Render, Railway, or a VPS). Set the start command to `npm start`. The host will provide a public HTTPS URL. Share that URL with friends; one player creates a room and everyone else joins with the five-character code.

**Important:** This starter stores rooms in server memory. Keep one server instance running; rooms reset if the server restarts. For a larger public launch, add persistent storage, rate limiting, moderation, and reconnection handling.

## Rules

- 4–9 players per room.
- 1 imposter by default; the host can choose 2 when there are 7–9 players.
- Everyone else receives the same secret word.
- Imposters receive a related hint word instead.
- Each player submits one clue, then players vote.
- If the group uniquely votes for an imposter, the non-imposters win. Otherwise, imposters win.
- Host can start another round after the reveal.

## Notes

This is a playable starter project, not a published/hosted game. It needs deployment to a public Node.js host before friends on different networks can join.
