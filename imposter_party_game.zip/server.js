const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;
app.use(express.static("public"));

const rooms = new Map();
const WORD_PAIRS = [
  ["Apple", "Fruit"], ["Book", "Novel"], ["Beach", "Sand"], ["Pizza", "Cheese"],
  ["Moon", "Planet"], ["Guitar", "Music"], ["School", "Classroom"], ["Coffee", "Tea"],
  ["Tiger", "Lion"], [" airplane", "Airport"], ["Pencil", "Pen"], ["Ocean", "Sea"],
  ["Basketball", "Football"], ["Cake", "Dessert"], ["Doctor", "Hospital"],
  ["Winter", "Snow"], ["Camera", "Photo"], ["Bicycle", "Helmet"], ["Dragon", "Monster"],
  ["Rainbow", "Colours"], ["Computer", "Keyboard"], ["Train", "Station"],
  ["Popcorn", "Cinema"], ["Shark", "Fish"], ["Garden", "Flowers"], ["Clock", "Time"],
  ["Chocolate", "Candy"], ["King", "Queen"], ["Fire", "Smoke"], ["Umbrella", "Rain"]
];

function cleanName(value) {
  return String(value || "").trim().replace(/[<>]/g, "").slice(0, 18);
}
function makeCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code;
  do {
    code = Array.from({length: 5}, () => chars[crypto.randomInt(chars.length)]).join("");
  } while (rooms.has(code));
  return code;
}
function roomPublic(room) {
  return {
    code: room.code,
    hostId: room.hostId,
    phase: room.phase,
    players: [...room.players.values()].map(p => ({
      id: p.id, name: p.name, ready: p.ready, isHost: p.id === room.hostId
    })),
    maxPlayers: 9,
    imposterCount: room.imposterCount,
    round: room.round,
    clues: room.clues,
    votesCast: room.votes.size
  };
}
function sendRoom(room) {
  io.to(room.code).emit("room:update", roomPublic(room));
}
function sendPrivate(room, player) {
  if (!player) return;
  io.to(player.id).emit("role:private", player.role ? {
    role: player.role, word: player.word, hint: player.hint, round: room.round
  } : null);
}
function leaveRoom(socket) {
  const code = socket.data.roomCode;
  if (!code) return;
  const room = rooms.get(code);
  socket.leave(code);
  socket.data.roomCode = null;
  if (!room) return;
  room.players.delete(socket.id);
  room.votes.delete(socket.id);
  room.clues = room.clues.filter(c => c.playerId !== socket.id);
  if (!room.players.size) {
    rooms.delete(code);
    return;
  }
  if (room.hostId === socket.id) room.hostId = room.players.keys().next().value;
  if (room.phase !== "lobby") {
    room.phase = "lobby";
    room.votes.clear();
    room.clues = [];
    for (const p of room.players.values()) {
      p.role = null; p.word = null; p.hint = null; p.ready = false;
    }
    io.to(code).emit("notice", "A player left. The game has returned to the lobby.");
  }
  sendRoom(room);
}

io.on("connection", socket => {
  socket.on("room:create", ({name}) => {
    const playerName = cleanName(name);
    if (!playerName) return socket.emit("error:message", "Enter a name first.");
    const code = makeCode();
    const player = {id: socket.id, name: playerName, ready: true, role: null, word: null, hint: null};
    const room = {code, hostId: socket.id, players: new Map([[socket.id, player]]),
      phase: "lobby", imposterCount: 1, round: 0, clues: [], votes: new Map(), result: null};
    rooms.set(code, room);
    socket.join(code); socket.data.roomCode = code;
    socket.emit("room:joined", {code, playerId: socket.id});
    sendRoom(room);
  });

  socket.on("room:join", ({name, code}) => {
    const playerName = cleanName(name);
    const roomCode = String(code || "").trim().toUpperCase();
    const room = rooms.get(roomCode);
    if (!playerName) return socket.emit("error:message", "Enter a name first.");
    if (!room) return socket.emit("error:message", "Room not found. Check the code.");
    if (room.phase !== "lobby") return socket.emit("error:message", "That game has already started.");
    if (room.players.size >= 9) return socket.emit("error:message", "This room is full (9 players maximum).");
    if ([...room.players.values()].some(p => p.name.toLowerCase() === playerName.toLowerCase()))
      return socket.emit("error:message", "That name is already taken in this room.");
    leaveRoom(socket);
    const player = {id: socket.id, name: playerName, ready: false, role: null, word: null, hint: null};
    room.players.set(socket.id, player);
    socket.join(roomCode); socket.data.roomCode = roomCode;
    socket.emit("room:joined", {code: roomCode, playerId: socket.id});
    sendRoom(room);
    io.to(roomCode).emit("notice", `${playerName} joined the room.`);
  });

  socket.on("player:ready", ready => {
    const room = rooms.get(socket.data.roomCode);
    const p = room && room.players.get(socket.id);
    if (!p || room.phase !== "lobby" || p.id === room.hostId) return;
    p.ready = !!ready; sendRoom(room);
  });

  socket.on("game:settings", count => {
    const room = rooms.get(socket.data.roomCode);
    if (!room || room.hostId !== socket.id || room.phase !== "lobby") return;
    room.imposterCount = Number(count) === 2 && room.players.size >= 7 ? 2 : 1;
    sendRoom(room);
  });

  socket.on("game:start", () => {
    const room = rooms.get(socket.data.roomCode);
    if (!room || room.hostId !== socket.id || room.phase !== "lobby") return;
    if (room.players.size < 4 || room.players.size > 9) return socket.emit("error:message", "You need 4–9 players to start.");
    const notReady = [...room.players.values()].filter(p => !p.ready && p.id !== room.hostId);
    if (notReady.length) return socket.emit("error:message", "Everyone must be ready before starting.");
    startRound(room);
  });

  function startRound(room) {
    room.round += 1; room.phase = "clues"; room.clues = []; room.votes.clear(); room.result = null;
    const pair = WORD_PAIRS[crypto.randomInt(WORD_PAIRS.length)];
    const [word, hint] = pair;
    const players = [...room.players.values()];
    const shuffled = players.sort(() => Math.random() - 0.5);
    const imposters = new Set(shuffled.slice(0, room.imposterCount).map(p => p.id));
    for (const p of players) {
      p.role = imposters.has(p.id) ? "imposter" : "player";
      p.word = imposters.has(p.id) ? null : word;
      p.hint = imposters.has(p.id) ? hint : null;
      sendPrivate(room, p);
    }
    sendRoom(room);
    io.to(room.code).emit("notice", "Round started! Check your secret word privately.");
  }

  socket.on("clue:send", text => {
    const room = rooms.get(socket.data.roomCode);
    const p = room && room.players.get(socket.id);
    const clue = String(text || "").trim().slice(0, 100);
    if (!room || !p || room.phase !== "clues" || !clue) return;
    if (room.clues.some(c => c.playerId === socket.id)) return socket.emit("error:message", "You have already submitted a clue this round.");
    room.clues.push({playerId: socket.id, name: p.name, text: clue});
    io.to(room.code).emit("clues:update", room.clues.map(c => ({name:c.name, text:c.text})));
    if (room.clues.length === room.players.size) {
      room.phase = "voting";
      io.to(room.code).emit("notice", "All clues are in. Discuss, then vote!");
      sendRoom(room);
    } else sendRoom(room);
  });

  socket.on("game:beginVoting", () => {
    const room = rooms.get(socket.data.roomCode);
    if (!room || room.hostId !== socket.id || room.phase !== "clues") return;
    room.phase = "voting"; sendRoom(room);
    io.to(room.code).emit("notice", "Voting is open!");
  });

  socket.on("vote:cast", targetId => {
    const room = rooms.get(socket.data.roomCode);
    if (!room || room.phase !== "voting" || !room.players.has(socket.id) ||
        !room.players.has(targetId) || targetId === socket.id || room.votes.has(socket.id)) return;
    room.votes.set(socket.id, targetId);
    io.to(socket.id).emit("vote:received");
    sendRoom(room);
    if (room.votes.size === room.players.size) finishVote(room);
  });

  function finishVote(room) {
    const tally = {};
    for (const target of room.votes.values()) tally[target] = (tally[target] || 0) + 1;
    const max = Math.max(0, ...Object.values(tally));
    const winners = Object.keys(tally).filter(id => tally[id] === max);
    const caught = winners.length === 1 ? room.players.get(winners[0]) : null;
    const imposters = [...room.players.values()].filter(p => p.role === "imposter");
    const caughtImposter = caught && caught.role === "imposter";
    room.phase = "reveal";
    room.result = {
      caughtId: caught ? caught.id : null,
      caughtName: caught ? caught.name : null,
      tied: winners.length !== 1,
      imposters: imposters.map(p => p.name),
      word: [...room.players.values()].find(p => p.role === "player")?.word || "Unknown",
      hint: imposters[0]?.hint || "",
      impostersWin: !caughtImposter
    };
    io.to(room.code).emit("game:result", room.result);
    sendRoom(room);
  }

  socket.on("game:nextRound", () => {
    const room = rooms.get(socket.data.roomCode);
    if (!room || room.hostId !== socket.id || room.phase !== "reveal") return;
    startRound(room);
  });

  socket.on("room:leave", () => leaveRoom(socket));
  socket.on("disconnect", () => leaveRoom(socket));
});

server.listen(PORT, () => console.log(`Imposter Party running on port ${PORT}`));