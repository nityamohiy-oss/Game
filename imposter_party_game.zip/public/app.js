const socket = io();
const $ = id => document.getElementById(id);
let currentRoom = null, me = null, roomState = null, myRole = null, myVote = null, hasClued = false;
const screens = ["home","lobby","game"];
function show(id){screens.forEach(s=>$(s).classList.toggle("hidden",s!==id));}
function toast(msg){const el=$("toast");el.textContent=msg;el.classList.add("show");clearTimeout(toast.t);toast.t=setTimeout(()=>el.classList.remove("show"),2600)}
function name(){return $("name").value.trim()}
$("create").onclick=()=>{if(!name())return toast("Enter your player name.");socket.emit("room:create",{name:name()})};
$("join").onclick=()=>{if(!name())return toast("Enter your player name.");if(!$("code").value.trim())return toast("Enter a room code.");socket.emit("room:join",{name:name(),code:$("code").value})};
$("code").addEventListener("input",e=>e.target.value=e.target.value.toUpperCase().replace(/[^A-Z0-9]/g,""));
$("copy").onclick=async()=>{try{await navigator.clipboard.writeText(currentRoom);toast("Room code copied!")}catch{toast("Your room code is "+currentRoom)}};
$("leave").onclick=()=>{socket.emit("room:leave");currentRoom=null;me=null;show("home")};
$("ready").onclick=()=>{const next=$("ready").dataset.ready!=="true";socket.emit("player:ready",next);$("ready").dataset.ready=String(next);$("ready").textContent=next?"✓ Ready":"I'm ready"};
$("imposterCount").onchange=e=>socket.emit("game:settings",Number(e.target.value));
$("start").onclick=()=>socket.emit("game:start");
$("sendClue").onclick=sendClue;
$("clueInput").addEventListener("keydown",e=>{if(e.key==="Enter")sendClue()});
function sendClue(){const v=$("clueInput").value.trim();if(!v)return toast("Write a clue first.");socket.emit("clue:send",v);$("clueInput").value="";$("sendClue").disabled=true;hasClued=true;$("clueStatus").textContent="Clue submitted. Waiting for everyone..."}
$("openVote").onclick=()=>socket.emit("game:beginVoting");
$("nextRound").onclick=()=>socket.emit("game:nextRound");
socket.on("room:joined",d=>{currentRoom=d.code;me=d.playerId;$("roomCode").textContent=d.code;show("lobby")});
socket.on("room:update",r=>{roomState=r;renderRoom(r);if(r.phase!=="lobby")renderPhase(r)});
socket.on("error:message",toast);
socket.on("notice",toast);
socket.on("role:private",role=>{myRole=role;if(role){hasClued=false;myVote=null;$("sendClue").disabled=false;$("clueInput").disabled=false;$("clueStatus").textContent="";$("voteStatus").textContent="";renderSecret(role)}});
socket.on("clues:update",clues=>{renderClues(clues)});
socket.on("vote:received",()=>{$("voteStatus").textContent="Vote submitted. Waiting for the others...";document.querySelectorAll(".vote-option").forEach(b=>b.disabled=true)});
socket.on("game:result",renderResult);
function renderRoom(r){
 $("playerCount").textContent=`${r.players.length}/9`;
 $("players").innerHTML=r.players.map(p=>`<div class="player"><div class="avatar">${escapeHtml(p.name[0].toUpperCase())}</div><div class="player-name">${escapeHtml(p.name)}${p.isHost?" <span style='color:#bbaaff'>★</span>":""}</div><div class="player-state">${p.isHost?"HOST":p.ready?"READY":"NOT READY"}</div></div>`).join("");
 const host=r.hostId===me;
 $("hostSettings").classList.toggle("hidden",!host);
 $("start").classList.toggle("hidden",!host);
 $("ready").classList.toggle("hidden",host);
 $("readyHint").textContent=host?(r.players.length<4?"Need at least 4 players to start.":r.players.every(p=>p.ready)?"Everyone is ready!":"Waiting for everyone to be ready..."):"Tap ready when you're in.";
 $("start").disabled=r.players.length<4||r.players.length>9||!r.players.every(p=>p.ready);
 if(r.imposterCount!==Number($("imposterCount").value))$("imposterCount").value=String(r.imposterCount);
 if(r.phase==="lobby")show("lobby");
}
function renderSecret(role){
 $("secretCard").classList.remove("hidden");
 $("roleLabel").textContent=role.role==="imposter"?"YOUR HINT WORD — YOU ARE THE IMPOSTER":"YOUR SECRET WORD";
 $("secretWord").textContent=(role.role==="imposter"?role.hint:role.word).toUpperCase();
 $("secretHint").textContent=role.role==="imposter"?"Blend in. Figure out the real word without getting caught.":"Keep it secret. Give clues that prove you know the word.";
 $("secretCard").style.borderColor=role.role==="imposter"?"#a94e83":"#514276";
}
function renderPhase(r){
 show("game");$("roundPill").textContent="ROUND "+r.round;$("phaseLabel").textContent="ROUND "+r.round;
 $("clueArea").classList.toggle("hidden",r.phase!=="clues");
 $("voteArea").classList.toggle("hidden",r.phase!=="voting");
 $("resultArea").classList.toggle("hidden",r.phase!=="reveal");
 $("phaseTitle").textContent=r.phase==="clues"?"Give your clue":r.phase==="voting"?"Find the imposter":"Round results";
 $("openVote").classList.toggle("hidden",!(r.hostId===me&&r.phase==="clues"&&r.clues.length>0));
 $("clueStatus").textContent=`${r.clues.length}/${r.players.length} clues submitted`;
 if(r.phase==="clues"){$("sendClue").disabled=hasClued;$("clueInput").disabled=hasClued}
 if(r.phase==="voting")renderVote(r);
 if(r.phase==="reveal")$("secretCard").classList.add("hidden");
}
function renderClues(clues){$("clueList").innerHTML=clues.map(c=>`<div class="clue"><b>${escapeHtml(c.name)}</b><span>${escapeHtml(c.text)}</span></div>`).join("");}
function renderVote(r){
 $("voteStatus").textContent=`${r.votesCast}/${r.players.length} votes received`;
 $("votePlayers").innerHTML=r.players.filter(p=>p.id!==me).map(p=>`<button class="vote-option ${myVote===p.id?"selected":""}" data-id="${p.id}" ${myVote?"disabled":""}>◯ &nbsp;${escapeHtml(p.name)}</button>`).join("");
 document.querySelectorAll(".vote-option").forEach(b=>b.onclick=()=>{myVote=b.dataset.id;socket.emit("vote:cast",myVote);renderVote(r)});
}
function renderResult(result){
 $("resultBanner").className="result-banner "+(result.impostersWin?"":"good");
 $("resultBanner").textContent=result.tied?"It's a tie! The imposters escape.":result.impostersWin?"The imposters fooled everyone!":"The imposter was caught!";
 $("revealDetails").innerHTML=`<b>Imposter${result.imposters.length>1?"s":""}:</b> ${result.imposters.map(escapeHtml).join(", ")}<br><b>Real word:</b> ${escapeHtml(result.word)}<br><b>Imposter hint:</b> ${escapeHtml(result.hint)}<br><b>Vote result:</b> ${result.tied?"Tie":escapeHtml(result.caughtName)+" was voted out."}`;
 $("nextRound").classList.toggle("hidden",roomState?.hostId!==me);
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
